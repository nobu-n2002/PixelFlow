# Test case -2D cylinder-

## porosity settings

![global cond.](fig/test-cylinder.png)

filename: porosity_cylinder.csv
dimension: 1024$\Delta$x512$\Delta$
thickness: 1.5
radius: 16$\Delta$

Boundary conditions: Periodic boundary conditions on the top and bottom, uniform flow (left), pressure fixed (right).

## Running Simulation

Run the simulation script.

```bash
sh run.sh
```

You will be prompted to select an executable file, so please choose either ibm2_drag_omp or ibm2_omp.Please enter the number of OpenMP parallel threads.

```bash
Available executable files:
0: ibm2_drag_omp
1: ibm2_omp
2: ibm3_air_condition_omp
3: ibm3_omp
Enter the number of the executable file to run: 1
Enter the number of threads to use for execution:3
Running ibm2_omp...
```

The processes are output to runlog_*.txt files inside the logs folder.
Additionally, execution information is output to process.txt inside the logs folder.
