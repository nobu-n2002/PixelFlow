import output_porosity as output
import numpy as np
import math
import seaborn as sns
import matplotlib.pyplot as plt

# ===== parameter =====
H = 400
h = 300
D = 10

l = 5*h
L = int(l + l/2)

thickness = 1.5
nu = 0.001 # Pa.s
dx = 0.0005 # m
u = 1.0 # m/s
dt = 0.1/2000
# ====================

m, n = L + 1, H + D + 1
step_hight = H - h
cen = (n-1)/2

data = np.ones((m,n))

re = u*dx*h/nu
pe = u*dx/nu
cfl = u*dt/dx


print(f'Uin: {u}')
print(f"Re: {re}")
print(f"Pe: {pe}")
print(f"CFL: {cfl}")
print(f'(m, n): ({m},{n})')
print(f"width: {(m-1)*dx} m")
print(f"height: {(n-1)*dx} m")
print(f'center: {l/L}')
print(f'H: {H}')
print(f'h: {h}')
print(f'D: {D}')
print(f'L: {L}')
print(f'l: {l}')

for i in range(m):
    for j in range(n):
        dist = float("inf")

        # upper part
        dist =  min(dist, j - D/2 - cen)

        if i - l <= 0:
            dist =  min(dist, j - D/2 - step_hight - cen)
            if j - D/2 - step_hight  - cen <= 0:
                dist =  max(dist, j - D/2 - step_hight  - cen)
            else:
                dist =  min(dist, j - D/2 - step_hight  - cen)
            
        if j - D/2 - cen <= 0 and i - l <= 0:
            dist = max(dist, -math.sqrt((i-(l))*(i-(l))+(j-(D/2+cen))*(j-(D/2+cen))))

        if j - D/2 - step_hight - cen <= 0 and j - D/2 - cen >= 0:
            if i - l <= 0:
                dist =  max(dist, i - l)
            else:
                dist =  min(dist, i - l)

        if j - D/2 - step_hight - cen >= 0:
            dist = min(dist, math.sqrt((i-l)*(i-l)+(j-(step_hight+D/2+cen))*(j-(step_hight+D/2+cen))))

        # lower part
        dist = max(dist, - (j + D/2 - cen))

        data[i, j] = min(data[i,j], 0.5*np.tanh(dist/thickness)+0.5)        

output.write_porosity_2d(data,f"../data/porosity_{thickness}_{h}.csv")

sns.heatmap(data, square=True)
plt.show()